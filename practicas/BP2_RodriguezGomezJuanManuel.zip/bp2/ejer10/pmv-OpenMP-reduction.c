#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

//#define VAR_GLOBAL // Variables globales
#define VAR_DYNAMIC // Variables dinámicas

#ifdef VAR_GLOBAL
#define MAX 32768	// =2^15
  double m[MAX][MAX], v[MAX], mv[MAX];
#endif

int main(int argc, char ** argv) {

    // Variables para la obtención de tiempos de ejecución
    double t_inicio, t_fin;
    double ncgt;

    // Comprobación del paso de argumentos
    if(argc < 2){
        printf("Error: Numero de argumentos insuficiente\n");
        printf("Uso: %s [TAM]", argv[0]);
        exit(-1);
    }

    // Dimensiones del vector y la matriz
    unsigned int tam = atoi(argv[1]);
    printf("Dimensiones del vector y la matriz : %u (%lu B)\n", tam, sizeof(unsigned int));

    // Ajuste de dimensión (para variables globales) y reserva de memoria (para variables dinámicas)
    #ifdef VAR_GLOBAL
        if(tam > MAX) tam = MAX;
    #endif

    #ifdef VAR_DYNAMIC

        // Declaración de las variables dinámicas
        double **m;
        double *v;
        double *mv;

        // Reserva de memoria dinámica
        m = (double**) malloc(tam * sizeof(double *)); // Memoria para matriz
        v = (double*) malloc(tam * sizeof(double)); // Memoria para vector
        mv = (double*) malloc(tam * sizeof(double)); // Memoria para la multiplicación matriz por vector

        // Comprobación de la asignación de memoria dinámica
        if(v == NULL || mv == NULL || m == NULL){
            printf("Error: Reserva de memoria dinamica fallida para la matriz o el vector\n");
            exit(EXIT_FAILURE);
        }

        // Reserva de memoria para la matriz
        for(int i=0; i<tam; i++) {

            m[i] = (double*) malloc(tam * sizeof(double));

            // Comprobación de la asignación de memoria dinámica
            if(m[i] == NULL) {
                printf("Error: Reserva de memoria dinamica fallida para la matriz\n");
                exit(EXIT_FAILURE);
            }
        }
    #endif

    // Inicialización del vector, la matriz y el producto de ambos
    int i, j;
    
    for(i=0; i<tam; i++)
    {

        v[i] = tam*0.1 + i*0.1;

        mv[i] = 0;

        #pragma omp parallel for
        for(j=0; j<tam; j++)
            m[i][j] = tam*0.1 + i*0.1 - j*0.1;
    }


    // Cálculo del producto de la matriz por el vector
    double suma;
 
    t_inicio = omp_get_wtime();

    for(int i=0; i<tam ; i++) {
        suma = 0;

        #pragma omp parallel
        {
            #pragma omp for reduction(+:suma)
            for(j=0; j<tam; j++)
                suma += m[i][j] * v[j];

            mv[i] = suma;
        }
    }

    t_fin = omp_get_wtime();

    // Muestra del resultado
    if(tam < 10) {

        // Matriz
        printf("Matriz M: \n");
        for(int i=0; i<tam; i++) {

            for(int j=0; j<tam; j++)
                printf("%11.9f \t", m[i][j]);

            printf("\n");
        }

        printf("\n");

        // Vector
        printf("Vector V: [");
        for(int i=0; i<tam; i++)
            printf("%11.9f \t", v[i]);
        printf("]\n");

        // Producto de la matriz por el vector
        printf("Producto M x V: [");
        for(int i=0; i<tam; i++){
            printf("%11.9f \t", mv[i]);
        }
        printf("]\n");
    }
    else {
        // Matriz
        printf("Matriz M: m[0][0]=%11.9f || m[%d][%d]=%11.9f \n", m[0][0], tam-1, tam-1, m[tam-1][tam-1]);
        // Vector
        printf("Vector V: v[0]=%11.9f || v[%d]=%11.9f \n", v[0], tam-1, v[tam-1]);
        // Producto de la matriz por el vector
        printf("Producto M x V: mv[0]=%11.9f || mv[%d]=%11.9f \n", mv[0], tam-1, mv[tam-1]);
    }

    // Cálculo y muestra del tiempo de ejecución del producto de la matriz por el vector
    ncgt= t_fin - t_inicio;
    printf("Tiempo de ejecucion: %11.9f || Dimension: %d \n", ncgt, tam);

    // Liberación de la memoria dinámica empleada
    #ifdef VAR_DYNAMIC
        free(v);
        free(mv);
        for(int i=0; i<tam; i++)
            free(m[i]);
        free(m);
    #endif

    return EXIT_SUCCESS;
}