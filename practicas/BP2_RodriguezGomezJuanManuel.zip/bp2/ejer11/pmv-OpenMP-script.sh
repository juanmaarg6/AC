#!/bin/bash
#Nombre: pmv-OpenMP-script.sh
#Author: Juan Manuel Rodríguez Gómez
#Descripción:
#Uso: ./pmv-OpenMP-script.sh

# TAMAÑOS
TAMANIO1=7500
TAMANIO2=30000

echo -e "\n Ejecucion de pmv-OpenMP-a:\n"
echo -e "\n Resultados para TAMANIO=$TAMANIO1:\n"
for((P=1;P<17;P++)) 
do
	echo -e "\n -Para $P nucleos:" 
	srun -c$P ./pmv-OpenMP-a $TAMANIO1
done

	echo -e "\n -Para 32 nucleos:" 
	srun -c32 ./pmv-OpenMP-a $TAMANIO1
	
echo -e "\n Resultados para TAMANIO=$TAMANIO2:\n"
for((P=1;P<17;P++)) 
do
	echo -e "\n -Para $P nucleos:" 
	srun -c$P ./pmv-OpenMP-a $TAMANIO2
done

	echo -e "\n -Para 32 nucleos:" 
	srun -c32 ./pmv-OpenMP-a $TAMANIO2
