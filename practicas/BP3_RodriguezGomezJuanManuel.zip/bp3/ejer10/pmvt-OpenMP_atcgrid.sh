#!/bin/bash
#Author: Juan Manuel Rodriguez Gomez
#Grupo Prácticas: 3
#Descripción: Ejecuta el programa pmtv-OpenMP en atcgrid
#Uso: ./pmtv-OpenMP_atcgrid.sh

#Órdenes para el sistema de colas:
#1. Asigna al trabajo un nombre
#SBATCH --job-name=pmtv-OpenMP
#2. Asignar el trabajo a una cola (partición) 
#SBATCH --partition=ac 
#2. Asignar el trabajo a un account 
#SBATCH --account=ac

#Obtener información de las variables del Gestor de carga de trabajo:
echo "Id. usuario del trabajo: $SLURM_JOB_USER"
echo "Id. del trabajo: $SLURM_JOBID"
echo "Nombre del trabajo especificado por usuario: $SLURM_JOB_NAME"
echo "Directorio de trabajo (en el que se ejecuta el script): $SLURM_SUBMIT_DIR"
echo "Cola: $SLURM_JOB_PARTITION"
echo "Nodo que ejecuta este trabajo:$SLURM_SUBMIT_HOST"
echo "Nº de nodos asignados al trabajo: $SLURM_JOB_NUM_NODES"
echo "Nodos asignados al trabajo: $SLURM_JOB_NODELIST"
echo "CPUs por nodo: $SLURM_JOB_CPUS_PER_NODE"

#Instrucciones para la ejecución del código:

NUM=15360

declare -a planificacion=("static" "dynamic" "guided")

for i in "${planificacion[@]}"
do
	for (( j = 0; j < 3; ++j )); do
		if [ $j -eq 0 ]; then
			echo "Planificacion: $i | Chunk: DEFAULT"
			export OMP_SCHEDULE=$i
		elif [ $j -eq 1 ]; then
			echo "Planificacion: $i | Chunk: 1"
			export OMP_SCHEDULE="$i,1"
		elif [ $j -eq 2 ]; then
			echo "Planificacion: $i | Chunk: 64"
			export OMP_SCHEDULE="$i,64"
		fi
		srun ./pmtv-OpenMP $NUM
	done
done