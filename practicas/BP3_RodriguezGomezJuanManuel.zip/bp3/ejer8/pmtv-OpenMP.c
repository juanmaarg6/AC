#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#ifdef _OPENMP
    #include <omp.h>
#else
    #define omp_get_num_threads() 0
#endif

#define VAR_DYNAMIC // Cálculos realizados con variables dinámicas

int main(int argc, char ** argv){

    double t_inicial, t_final;
    double ncgt;

    // Comprobación de los argumentos
    if(argc < 2){
        printf("Error: Numero de argumentos insuficiente\n");
        printf("Uso: %s [TAM]", argv[0]);
        exit(-1);
    }

    // Dimensiones del vector y la matriz
    unsigned int tam = atoi(argv[1]);
    printf("Dimensiones del vector y la matriz : %u (%lu B)\n", tam, sizeof(unsigned int));

    // Reserva de memoria dinamica
    #ifdef VAR_DYNAMIC
        // Declaración de las variables dinámicas
        double **m;
        double *v;
        double *mv;

        // Reserva de memoria dinámica
        m = (double**) malloc(tam * sizeof(double*)); // Memoria para matriz
        v = (double*) malloc(tam * sizeof(double)); // Memoria para vector
        mv = (double*) malloc(tam * sizeof(double)); // Memoria para la multiplicación matriz por vector

        // Comprobación de la asignación de memoria dinámica
        if(v == NULL || mv == NULL || m == NULL){
            printf("Error: Reserva de memoria dinamica fallida para la matriz o el vector\n");
            exit(-1);
        }

        // Reserva de memoria para la matriz
        for(int i = 0; i < tam; i++) {

            m[i] = (double*) malloc(tam * sizeof(double));

            // Comprobación de la asignación de memoria dinámica
            if(m[i] == NULL) {
                printf("Error: Reserva de memoria dinamica fallida para la matriz\n");
                exit(-1);
            }
        }
    #endif

    // Inicialización del vector, la matriz y el producto de ambos
    for(int i = 0; i < tam; i++) {

        v[i] = tam*0.1 + i*0.1;

        mv[i] = 0;

        for(int j = 0; j < tam; j++) {
            if(i > j)
                m[i][j] = 0;
            else
                m[i][j] = tam*0.1 + i*0.1 - j*0.1;
        }
    }

    // Cálculo del producto de la matriz por el vector
    double suma;

    #pragma omp parallel
    {
        #pragma omp single
        t_inicial = omp_get_wtime();

        #pragma omp for firstprivate(suma) schedule(runtime)
        for(int i = 0; i < tam ; i++) {
            suma = 0;

            for(int j = i; j < tam; j++)
                suma += m[i][j] * v[j];

            mv[i] = suma;
        }

        #pragma omp single
        t_final = omp_get_wtime();
    }

    // Muestra del resultado
    if(tam < 10) {
        // Matriz
        printf("Matriz M: \n");
        for(int i = 0; i < tam; i++) {
            
            for(int j = 0; j < tam; j++)
                printf("%11.9f \t", m[i][j]);
            
            printf("\n");
        }
        printf("\n");

        // Vector
        printf("Vector V: [");
        for(int i = 0; i < tam; i++)
            printf("%11.9f \t", v[i]);
        printf("]\n");

        // Producto de la matriz por el vector
        printf("Producto M x V: [");
        for(int i = 0; i < tam; i++)
            printf("%11.9f \t", mv[i]);
        printf("]\n");
    }
    else{
        // Matriz
        printf("Matriz M: m[0][0]=%11.9f || m[%d][%d]=%11.9f \n", m[0][0], tam-1, tam-1, m[tam-1][tam-1]);

        // Vector
        printf("Vector V: v[0]=%11.9f || v[%d]=%11.9f \n", v[0], tam-1, v[tam-1]);

        // Producto de la matriz por el vector
        printf("Producto M x V: mv[0]=%11.9f || mv[%d]=%11.9f \n", mv[0], tam-1, mv[tam-1]);
    }

    // Cálculo y muestra del tiempo de ejecución del producto de la matriz por el vector
    ncgt = t_final - t_inicial;
    printf("Tiempo de ejecucion: %11.9f || Dimension: %d \n", ncgt, tam);

    // Liberación de la memoria dinámica empleada
    #ifdef VAR_DYNAMIC
        free(v);

        free(mv);

        for(int i=0; i<tam; i++)
            free(m[i]);
        free(m);
    #endif

    return 0;
}