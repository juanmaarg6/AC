/**
 * @file figura1-original.c
 * @author Juan Manuel Rodríguez Gómez
 *
 * Compilacion: gcc -O2 figura1-original.c -o figura1-original
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {

    struct timespec cgt1,cgt2;
    double ncgt;

    int ii; 
    double X1, X2;

    // Leer argumentos de entrada
    if(argc < 3) {
        printf("Error en el numero de argumentos\n");
        exit(-1);
    }

    unsigned int N = atoi(argv[1]);

    // Struct
    struct {
        int a;
        int b;
    } s[N];

    unsigned int M = atoi(argv[2]);

    // Inicializar struct
    if((N < 9) && (M < 9))
        for(ii = 0; ii < N; ii++) {
            s[ii].a = ii;
            s[ii].b = ii+3;
        }
    else {
        srand(time(0));
         for(ii = 0; ii < N; ii++) {
            s[ii].a = rand() % 50;;
            s[ii].b = rand() % 50;;
        }
    }

    // Cálculos

    double R[M];

    clock_gettime(CLOCK_REALTIME,&cgt1);

    for(ii = 0; ii < M; ii++) {
        X1 = 0; X2 = 0;
        for(int i = 0; i < N; i+=4) {
            X1 += 2*s[i].a + ii;
            X2 += 3*s[i].b - ii;
            X1 += 2*s[i+1].a + ii;
            X2 += 3*s[i+1].b - ii;
            X1 += 2*s[i+2].a + ii;
            X2 += 3*s[i+2].b - ii;
            X1 += 2*s[i+3].a + ii;
            X2 += 3*s[i+3].b - ii;
        }

        if(X1 < X2) 
            R[ii] = X1; 
        else 
            R[ii] = X2;
    }

    clock_gettime(CLOCK_REALTIME,&cgt2);

    // Imprimir resultado y el tiempo de ejecución
    printf("RESULTADOS ALMACENADOS EN EL VECTOR R:\n");
    for(ii = 0; ii<5; ii++)
        printf("\t --> R[%d] = %f\n", ii, R[ii]);

    if(M > 5) {
        printf("\n ...../\n");
        for(int ii = M-5; ii < M; ii++)
            printf("\t --> R[%d] = %f\n",ii, R[ii]);

    }

    ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+(double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));
    printf("\n>> TIEMPO DE EJECUCION: %11.9f\n", ncgt);

    return 0;
}