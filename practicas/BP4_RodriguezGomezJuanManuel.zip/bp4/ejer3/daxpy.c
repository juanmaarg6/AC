/**
 * @file daxpy.c
 * @author Juan Manuel Rodríguez Gómez
 * @brief Implementacion de Double precision-real Alpha X Plus Y
 *
 * COMPILACIÓN: gcc [OPTIMIZACION] daxpy.c -o daxpy.o
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define MAX 134217728

double x[MAX];
double y[MAX];
double a = 12345.6789;

int main(int argc, char ** argv){
    
    // Leer argumentos de entrada
    if( (argc != 2) && (argc != 1) ) {
        printf("Error en el numero de argumentos\n");
        exit(-1);
    }

    int N;

    if(argc == 2){
        N = atoi(argv[1]);

        if(N > MAX)
            N = MAX;
    }

    if(argc == 1)
        N = MAX;

    // Inicializar vectores
    for(int i = 0; i < N; i++) {
        y[i] = a - i*0.1234;
        x[i] = a + i*0.1234;
    }

    // Cálculos
    struct timespec cgt1,cgt2;
    double ncgt;

    clock_gettime(CLOCK_REALTIME,&cgt1);

    for(int i = 0; i < N; i++)
        y[i] = a*x[i] + y[i];

    clock_gettime(CLOCK_REALTIME,&cgt2);

    // Imprimir resultado y el tiempo de ejecución
    printf("RESULTADOS ALMACENADOS EN EL VECTOR y:\n");
    for(int i = 0; i<5; i++)
        printf("\t --> y[%d] = %f\n", i, y[i]);

    if(N > 5) {
        printf("\n ...../\n");
        for(int i = N-5; i < N; i++)
            printf("\t --> y[%d] = %f\n",i, y[i]);

    }

    ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+(double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));
    printf("\nTIEMPO DE EJECUCION: %11.9f || DIMENSION: %d \n",ncgt, N);

    return 0;
}