/**
 * @file pmm-secuencial.c
 * @author Juan Manuel Rodríguez Gómez
 * @brief Implementacion de producto de matrices
 *
 * Compilacion: gcc -O2 pmm-secuencial.c -o pmm-secuencial
 */

#include <stdlib.h> // Biblioteca con funciones atoi(), rand(), srand(), malloc() y free()
#include <stdio.h>  // Biblioteca donde se encuentra la función printf()
#include <time.h>   // Biblioteca donde se encuentra la función clock_gettime()

#define MAX 1024  //=2^10

double m1[MAX][MAX];
double m2[MAX][MAX];
double mm[MAX][MAX];

#define VAR_DYNAMIC

int main(int argc, char** argv){
 
    struct timespec cgt1,cgt2; 
    double ncgt;
 
    // Leer argumento de entrada (Dimensión de las matrices cuadradas)
    if(argc < 2) {
        printf("Falta dimensión de las matrices cuadradas\n");
        exit(-1);
    }
 
    unsigned int N = atoi(argv[1]);
    if(N > MAX) 
        N = MAX;
 
    // Inicializar matrices
    if(N < 9)
        for(int i = 0; i < N; i++)
            for(int j = 0; j < N; j++) {
                m1[i][j] = N*0.1 + i*0.1 - j*0.1;
                m2[i][j] = i*0.1 + N;
                mm[i][j] = 0;
            }
    else {
        srand(time(0));
        for(int i = 0; i < N; i++)
            for(int j = 0; j < N; j++) {
                m1[i][j] = rand()/ ((double) rand()); 
                m2[i][j] = rand()/ ((double) rand()); 
                mm[i][j] = 0;
            }
    }

    // Calcular multiplicación de matrices
    double suma;

    clock_gettime(CLOCK_REALTIME, &cgt1);

    for(int i = 0; i < N ; i++)
        for(int j = 0; j < N; j++)
            for(int k = 0; k < N; k++)
                mm[i][j] += m1[i][k] * m2[k][j];


    clock_gettime(CLOCK_REALTIME, &cgt2);
 
    // Imprimir resultado de la multiplicación y el tiempo de ejecución
    printf("RESULTADOS DE LA MULTIPLICACION DE MATRICES:\n");
    for(int j = 0; j < 5; j++)
        printf("\t --> mm[%d][%d] = %f\n", 0, j, mm[0][j]);

    if(N >= 5) {
        printf("\n ...../\n");
        for(int j = N-5; j < N; j++)
            printf("\t --> mm[%d][%d] = %f\n", N-1, j, mm[N-1][j]);
    }
    
    ncgt = (double)(cgt2.tv_sec-cgt1.tv_sec) + (double)((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));
    printf("\nTIEMPO DE EJECUCION: %11.9f || DIMENSION: %d \n",ncgt, N);

   return 0;
}