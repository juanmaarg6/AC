#!/bin/bash
#Nombre: pvv-OpenMP-script.sh
#Author: Juan Manuel Rodríguez Gómez
#Uso: ./pvv-OpenMP-script.sh

#Obtener información de las variables del Gestor de carga de trabajo:
echo "Id. usuario del trabajo: $SLURM_JOB_USER"
echo "Id. del trabajo: $SLURM_JOBID"
echo "Nombre del trabajo especificado por usuario: $SLURM_JOB_NAME"
echo "Directorio de trabajo (en el que se ejecuta el script): $SLURM_SUBMIT_DIR"
echo "Cola: $SLURM_JOB_PARTITION"
echo "Nodo que ejecuta este trabajo:$SLURM_SUBMIT_HOST"
echo "Nº de nodos asignados al trabajo: $SLURM_JOB_NUM_NODES"
echo "Nodos asignados al trabajo: $SLURM_JOB_NODELIST"
echo "CPUs por nodo: $SLURM_JOB_CPUS_PER_NODE"

#Instrucciones del script para ejecutar código:

#Tamaño del vector
TAMANIO=30000

#Ejecución de pvv-parallel-for
echo -e "\n Ejecucion de pvv-parallel-for:\n"
echo -e "\n Resultados para TAMANIO=$TAMANIO:\n"
for((H=1;H<25;H++)) 
do
    export OMP_NUM_THREADS=$H;
	echo -e "\n -Para $H hebras:" 
	srun ./pvv-parallel-for $TAMANIO
done

echo -e "\n /*********************************/"
echo -e "\n /*********************************/"
echo -e "\n /*********************************/ \n"

#Ejecución de pvv-parallel-for-simd
echo -e "\n Ejecucion de pvv-parallel-for-simd:\n"
echo -e "\n Resultados para TAMANIO=$TAMANIO:\n"
for((H=1;H<25;H++)) 
do
    export OMP_NUM_THREADS=$H;
	echo -e "\n -Para $H hebras:" 
	srun ./pvv-parallel-for-simd $TAMANIO
done


