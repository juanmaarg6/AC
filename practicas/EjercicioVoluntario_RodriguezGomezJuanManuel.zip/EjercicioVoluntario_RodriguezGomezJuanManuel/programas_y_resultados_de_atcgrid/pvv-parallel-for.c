/**
 * @file pvv-parallel-for.c
 * @author Juan Manuel Rodríguez Gómez
 * @brief Implementacion de producto de vectores
 *
 * Compilacion: gcc -O2 -fopenmp pvv-parallel-for.c -o pvv-parallel-for
 */

#include <stdlib.h> // Biblioteca con funciones atoi() y rand()
#include <stdio.h>  // Biblioteca donde se encuentra la función printf()
#include <time.h>   // Biblioteca donde se encuentra la función time()
#include <omp.h>    // Biblioteca OpenMP

#define MAX 30000

int main(int argc, char** argv){
 
    float a[MAX];
    float b[MAX];
    float c[MAX];
    
    double cgt1, cgt2; 
    double ncgt;
 
    // Leer argumento de entrada (Dimensión de los vectores)
    if(argc < 2) {
        printf("Falta dimensión de los vectores\n");
        exit(-1);
    }
 
    unsigned int N = atoi(argv[1]);
    if(N > MAX) 
        N = MAX;
 
    // Inicializar vectores
    srand(time(0));
    for(int i = 0; i < N; i++) {
        a[i] = (float)rand(); 
        b[i]= (float)rand(); 
        c[i] = 0;
    }

    // Calcular multiplicación de vectores
    cgt1 = omp_get_wtime();

    #pragma omp parallel for
    for(int i = 0; i < N ; ++i)
        c[i] = a[i] * b[i];


    cgt2 = omp_get_wtime();

    // Imprimir resultado de la multiplicación y el tiempo de ejecución
    printf("RESULTADOS DE LA MULTIPLICACION DE VECTORES:\n");
    if(N <= 10)
        for(int i = 0; i < N; ++i)
            printf("\t --> c[%d] = %f\n", i, c[i]);
    else {
        printf("\t --> c[%d] = %f\n", 0, c[0]);
        printf("\n\t ...../\n");
        printf("\n\t --> c[%d] = %f\n", N-1, c[N-1]);
    }
    
    ncgt = cgt2 - cgt1;
    printf("\nTIEMPO DE EJECUCION: %11.9f || DIMENSION: %d \n", ncgt, N);

   return 0;
}