#!/bin/bash
#Author: Juan Manuel Rodriguez Gomez
#Grupo Prácticas: 3
#Descripción: Ejecuta la Suma de Vectores en C desde 65536 hasta 67108864 en mi PC
#Uso: ./script_suma_vectores_pc.sh

MIN=65536
MAX=67108864

    echo -e "/************************LOCAL************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    ./SumaVectoresC_VECTOR_LOCAL $N
	    echo -e "\n"
        done

    echo -e "/************************GLOBAL************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    ./SumaVectoresC_VECTOR_GLOBAL $N
	    echo -e "\n"
        done
        
    echo -e "/************************DYNAMIC************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    ./SumaVectoresC_VECTOR_DYNAMIC $N
	    echo -e "\n"
        done
