#!/bin/bash
#Author: Juan Manuel Rodriguez Gomez
#Grupo Prácticas: 3
#Descripción: Ejecuta la Suma de Vectores en C desde 65536 hasta 67108864 en atcgrid
#Uso: ./script_suma_vectores_atcgrid.sh

#Órdenes para el sistema de colas:
#1. Asigna al trabajo un nombre
#SBATCH --job-name=helloOMP
#2. Asignar el trabajo a una partición (cola) 
#SBATCH --partition=ac 
#2. Asignar el trabajo a un account 
#SBATCH --account=ac

#Obtener información de las variables del Gestor de carga de trabajo:
echo "Id. usuario del trabajo: $SLURM_JOB_USER"
echo "Id. del trabajo: $SLURM_JOBID"
echo "Nombre del trabajo especificado por usuario: $SLURM_JOB_NAME"
echo "Directorio de trabajo (en el que se ejecuta el script): $SLURM_SUBMIT_DIR"
echo "Cola: $SLURM_JOB_PARTITION"
echo "Nodo que ejecuta este trabajo:$SLURM_SUBMIT_HOST"
echo "Nº de nodos asignados al trabajo: $SLURM_JOB_NUM_NODES"
echo "Nodos asignados al trabajo: $SLURM_JOB_NODELIST"
echo "CPUs por nodo: $SLURM_JOB_CPUS_PER_NODE"
#Instrucciones del script para ejecutar código:

MIN=65536
MAX=67108864

    echo -e "/************************LOCAL************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    srun ./SumaVectoresC_VECTOR_LOCAL $N
	    echo -e "\n"
        done

    echo -e "/************************GLOBAL************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    srun ./SumaVectoresC_VECTOR_GLOBAL $N
	    echo -e "\n"
        done
        
    echo -e "/************************DYNAMIC************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    srun ./SumaVectoresC_VECTOR_DYNAMIC $N
	    echo -e "\n"
        done
