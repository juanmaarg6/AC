#!/bin/bash
#Author: Juan Manuel Rodriguez Gomez
#Grupo Prácticas: 3
#Uso: ./sp-OpenMP-script10.sh

MIN=16384
MAX=67108864

    echo -e "/************************GLOBAL************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    ./SumaVectoresC-NuevoMAX $N
	    echo -e "\n"
        done

    echo -e "/************************PARALLEL FOR************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    ./sp-OpenMP-for-NuevoMAX $N
	    echo -e "\n"
        done
        
    echo -e "/************************PARALLEL SECTIONS************************/"
    for((N=$MIN; N<=$MAX; N=N*2))
        do
	    ./sp-OpenMP-sections-NuevoMAX $N
	    echo -e "\n"
        done
